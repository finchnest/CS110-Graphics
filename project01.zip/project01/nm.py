dic = {"eben": [1, 4], "ab": 4}
dic["eben"][1] = 6
print(dic["eben"][1])
print(dic["ab"])
